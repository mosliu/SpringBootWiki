/*
SQLyog Job Agent v12.09 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.26-log : Database - spring
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`spring` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `spring`;

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `summary` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `message` */

/*Table structure for table `persistent_logins` */

DROP TABLE IF EXISTS `persistent_logins`;

CREATE TABLE `persistent_logins` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `persistent_logins` */

insert  into `persistent_logins` values ('admin','/mEC0R1K3WGHpJHDbMc1AA==','fCXE+p+mfbVW6dBo/N5GCQ==','2016-03-29 13:20:32'),('user','diBQpJBitPnEdN+rCaQhTw==','NTFvIXWJpGQGXDk6fwqBWA==','2016-03-25 13:29:12'),('admin','T4jsE/ensQ0Yrsh0UoFA9g==','dG+XXOm0bwBcxfcOoSQXMw==','2016-03-29 15:53:23'),('admin','zhPXdngE2RhhFqWweNob0g==','ZO08RToLlLQuUehUcoVTmw==','2016-03-28 11:09:26');

/*Table structure for table `sprki_authorities` */

DROP TABLE IF EXISTS `sprki_authorities`;

CREATE TABLE `sprki_authorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authority` varchar(30) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_hpaossout1kdwdp73r985jndj` (`username`),
  CONSTRAINT `FK_hpaossout1kdwdp73r985jndj` FOREIGN KEY (`username`) REFERENCES `sprki_user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_authorities` */

insert  into `sprki_authorities` values (1,'ROLE_USER','admin'),(2,'ROLE_USER','user'),(3,'ROLE_AA','aaa'),(4,'ROLE_ADMIN','admin'),(5,'ROLE_ADMIN','admin'),(6,'ROLE_USER','11122');

/*Table structure for table `sprki_banner` */

DROP TABLE IF EXISTS `sprki_banner`;

CREATE TABLE `sprki_banner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_banner` */

/*Table structure for table `sprki_cms_category` */

DROP TABLE IF EXISTS `sprki_cms_category`;

CREATE TABLE `sprki_cms_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disabled` bit(1) NOT NULL,
  `english_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `page_size` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mcq3s46so9tuxa4wi0difayy` (`parent_id`),
  CONSTRAINT `FK_mcq3s46so9tuxa4wi0difayy` FOREIGN KEY (`parent_id`) REFERENCES `sprki_cms_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_category` */

insert  into `sprki_cms_category` values (1,'\0','category1','分类1',10,'/category',NULL),(2,'\0','category2','分类2',10,'/category2',NULL);

/*Table structure for table `sprki_cms_comment` */

DROP TABLE IF EXISTS `sprki_cms_comment`;

CREATE TABLE `sprki_cms_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_kind` varchar(20) DEFAULT NULL,
  `comment_content` varchar(255) DEFAULT NULL,
  `commentip` varchar(40) DEFAULT NULL,
  `comment_title` varchar(40) DEFAULT NULL,
  `disabled` bit(1) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `parent` int(11) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_fq2hx5s983ig1v4hx448ly0rv` (`parent`),
  KEY `FK_ckjlbg4px77m8n9vjor14n7u4` (`username`),
  CONSTRAINT `FK_ckjlbg4px77m8n9vjor14n7u4` FOREIGN KEY (`username`) REFERENCES `sprki_user` (`username`),
  CONSTRAINT `FK_fq2hx5s983ig1v4hx448ly0rv` FOREIGN KEY (`parent`) REFERENCES `sprki_cms_comment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_comment` */

/*Table structure for table `sprki_cms_content` */

DROP TABLE IF EXISTS `sprki_cms_content`;

CREATE TABLE `sprki_cms_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clicks` int(11) DEFAULT NULL,
  `comments_count` int(11) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `diggs` int(11) DEFAULT NULL,
  `disabled` bit(1) NOT NULL,
  `full_title` varchar(1000) DEFAULT NULL,
  `info_text` mediumtext NOT NULL,
  `is_copied` bit(1) NOT NULL,
  `last_update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `publish_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `score` int(11) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `source_url` varchar(200) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `subtitle` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `author` varchar(30) NOT NULL,
  `category` int(11) NOT NULL,
  `last_update_user` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_p7db0eu9e2dex594s13ywbnl0` (`author`),
  KEY `FK_92v5x3fsink8uq7968do91xr8` (`category`),
  KEY `FK_hqpe8d0f7dsgfdmq1n9pafgii` (`last_update_user`),
  CONSTRAINT `FK_92v5x3fsink8uq7968do91xr8` FOREIGN KEY (`category`) REFERENCES `sprki_cms_category` (`id`),
  CONSTRAINT `FK_hqpe8d0f7dsgfdmq1n9pafgii` FOREIGN KEY (`last_update_user`) REFERENCES `sprki_user` (`username`),
  CONSTRAINT `FK_p7db0eu9e2dex594s13ywbnl0` FOREIGN KEY (`author`) REFERENCES `sprki_user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_content` */

insert  into `sprki_cms_content` values (1,0,0,NULL,0,'\0',NULL,'','\0','2016-03-23 16:39:31',NULL,'2016-03-23 16:39:31',0,'','',0,NULL,'支持系统第一个问题！','admin',1,'admin'),(2,0,0,NULL,0,'\0',NULL,'','\0','2016-03-21 16:30:49',NULL,'2016-03-21 16:30:49',0,'','',0,NULL,'123123','user',1,'user'),(3,1,0,NULL,0,'\0',NULL,'','\0','2016-03-21 16:31:05',NULL,'2016-03-21 16:31:05',0,'','',0,NULL,'123123','user',1,'user'),(4,0,0,NULL,0,'\0',NULL,'','\0','2016-03-25 15:05:51',NULL,'2016-03-21 16:32:00',0,'','',0,NULL,'123123fff','user',1,'admin'),(5,0,0,NULL,0,'\0',NULL,'','\0','2016-03-21 16:53:19',NULL,'2016-03-21 16:53:18',0,'','',0,NULL,'14341','user',1,'user'),(6,0,0,NULL,0,'\0',NULL,'','\0','2016-03-22 15:20:30',NULL,'2016-03-22 15:20:30',0,'','',0,NULL,'44444444','user',1,'user'),(7,0,0,NULL,0,'\0',NULL,'','\0','2016-03-22 15:27:39',NULL,'2016-03-22 15:27:39',0,'','',0,NULL,'3333333','user',1,'user'),(8,0,0,NULL,0,'\0',NULL,'','\0','2016-03-24 09:34:47',NULL,'2016-03-22 15:29:18',0,'','',0,NULL,'1100老美标怎么改那个试验ID','user',1,'admin'),(9,0,0,NULL,0,'\0',NULL,'','\0','2016-03-22 15:30:16',NULL,'2016-03-22 15:30:16',0,'','',0,NULL,'eeeeeee','user',1,'user'),(10,0,0,NULL,0,'\0',NULL,'','\0','2016-03-25 13:35:48',NULL,'2016-03-22 15:33:56',0,'','',0,NULL,'eeeeeee','user',2,'user'),(11,0,0,NULL,0,'',NULL,'','\0','2016-03-22 15:34:15',NULL,'2016-03-22 15:34:15',0,'','',0,NULL,'33','user',1,'user'),(12,0,0,NULL,0,'',NULL,'','\0','2016-03-24 08:28:54',NULL,'2016-03-24 08:28:53',0,'','',0,NULL,'vdf','admin',1,'admin'),(13,0,0,NULL,0,'\0',NULL,'','\0','2016-03-24 09:25:37',NULL,'2016-03-23 07:50:40',0,'','',0,NULL,'麻烦帮确认下2013年7月份的XLW(M)与现在使用的主板是一样的吗？','admin',1,'admin'),(14,0,0,NULL,0,'\0',NULL,'','\0','2016-03-24 08:09:09',NULL,'2016-03-24 08:09:08',0,'','',0,NULL,'W3/031腔内的接近开关  型号？','admin',1,'admin'),(15,2,0,NULL,0,'\0',NULL,'','\0','2016-03-24 08:28:18',NULL,'2016-03-24 08:28:18',0,'','',0,NULL,'have a test','admin',1,'admin');

/*Table structure for table `sprki_cms_contentfaq` */

DROP TABLE IF EXISTS `sprki_cms_contentfaq`;

CREATE TABLE `sprki_cms_contentfaq` (
  `answer` mediumtext NOT NULL,
  `question` mediumtext NOT NULL,
  `faq_id` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `devices` int(11) DEFAULT NULL,
  `question_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`faq_id`),
  KEY `FK_4gl4gcpkq0vo2rbk4chj6gf2d` (`devices`),
  KEY `FK_hfo0f762jhntnq6ppm4ejqkn4` (`department`),
  CONSTRAINT `FK_4gl4gcpkq0vo2rbk4chj6gf2d` FOREIGN KEY (`devices`) REFERENCES `sprki_labthink_devices` (`id`),
  CONSTRAINT `FK_hfo0f762jhntnq6ppm4ejqkn4` FOREIGN KEY (`department`) REFERENCES `sprki_labthink_department` (`id`),
  CONSTRAINT `FK_jyqdfj6eiu9c2c3t1xcdf6axq` FOREIGN KEY (`faq_id`) REFERENCES `sprki_cms_content` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_contentfaq` */

insert  into `sprki_cms_contentfaq` values ('<p>理论上没问题</p><p>我找工程师确认下</p><p>找王连佳确认：没问题</p><p><img src=\"/ueditor/jsp/upload/image/20160323/1458722333434075676.jpg\" title=\"1458722333434075676.jpg\" alt=\"http_imgloadCA2IU2WB.jpg\"/></p>','<div>* 单 位：广东电网公司电力科学研究院（培训）郭思嘉 工程师上门再把低温箱培训下，另外两台客户会有人上门调试&nbsp;</div><div>地 址：广州市番禺区南村镇兴业大道南侧南村工业区A区骏拓工业园一号楼&nbsp;</div><div>联系人：赵耀洪18826469062&nbsp;</div><div>产 品： MGT-01订制编号：DZ201508040003 不含气相色谱仪&nbsp;</div><div>送货前请先联系郭思嘉13631382021、GT-7008-TR低温回缩试验机 厂家直发、GT-7017-URP换气式老化试验机厂家直发、DW-50W255低温箱厂家直发&nbsp;</div><div>发 货： 德邦304420118 10/9一个木箱二个纸箱 送货前请先联系郭思嘉13631382021，售后请提前联系客户准备事宜，客户测试气体为六氟化硫，并请让客户预约安捷伦工程师仪器上门安装调试，费用由客户承担。&nbsp;</div><div><br></div><div>这台设备可以用氩气做载气吗</div>',1,1,1,'2016-03-11 00:00:00'),('','123',2,1,1,'2016-03-11 00:00:00'),('','123',3,1,1,'2016-03-11 00:00:00'),('','123',4,1,1,'2016-03-11 00:00:00'),('','513451435',5,1,1,'2016-03-24 00:00:00'),('<p>fffffffffff</p>','44444444',6,2,1,'2016-03-25 14:56:16'),('','4444',7,1,1,'2016-03-03 00:00:00'),('<p>在userdata 下的 Sysini.xml 里 S_TestID</p>','你知道1100老美标怎么改那个试验ID吗？售后借我们设备 回来以后软件给换了 现在iD从21开始了 &nbsp;但是原来都到9582了 &nbsp;如果不改回去 会导致云检测这边数据重复&nbsp;',8,1,1,'2016-03-03 00:00:00'),('<p>555</p>','444',9,1,1,'2016-03-24 00:00:00'),('<p>555</p>','444',10,1,1,'2016-03-24 00:00:00'),('<p>55</p>','44',11,1,1,'2016-03-24 00:00:00'),('<p>gh</p>','dsfg',12,1,1,'2016-03-18 00:00:00'),('<p>确定不是刘红旗的板子</p><p>现在用的都是带拉线位移传感器的，和以前不带拉线位移传感器的是不通用的</p><p>刘红旗的除了一台英国的，其他都是新的拉绳的</p><p>是不是刘红旗的可以查看关于以知道</p><p><br/></p>','麻烦帮确认下2013年7月份的XLW(M)与现在使用的主板是一样的吗？',13,1,1,'2016-03-10 00:00:00'),('<p>LJ8A3-1-Z／BX(平头,35mm) &nbsp;刘思广处获取</p><p>24V &nbsp;杨继伟处获取</p><p><br/></p>','<div>W3/031腔内的接近开关 &nbsp;型号是这个吗？</div><div>供电是12V的吗？</div>',14,1,2,'2016-03-02 00:00:00'),('<p>have a test</p>','have a test',15,1,1,'2016-03-05 00:00:00');

/*Table structure for table `sprki_cms_contents_tags` */

DROP TABLE IF EXISTS `sprki_cms_contents_tags`;

CREATE TABLE `sprki_cms_contents_tags` (
  `content_id` int(11) NOT NULL,
  `tags_id` int(11) NOT NULL,
  PRIMARY KEY (`content_id`,`tags_id`),
  KEY `FK_nj1g0b3kjw5tbrbdrr07o14mw` (`tags_id`),
  CONSTRAINT `FK_2ecrcq6fflkk5nadlf846v93t` FOREIGN KEY (`content_id`) REFERENCES `sprki_cms_content` (`id`),
  CONSTRAINT `FK_nj1g0b3kjw5tbrbdrr07o14mw` FOREIGN KEY (`tags_id`) REFERENCES `sprki_cms_tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_contents_tags` */

/*Table structure for table `sprki_cms_tags` */

DROP TABLE IF EXISTS `sprki_cms_tags`;

CREATE TABLE `sprki_cms_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `tagtype` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_cms_tags` */

/*Table structure for table `sprki_labthink_department` */

DROP TABLE IF EXISTS `sprki_labthink_department`;

CREATE TABLE `sprki_labthink_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(80) NOT NULL,
  `department_namecn` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_labthink_department` */

insert  into `sprki_labthink_department` values (1,'售后','售后'),(2,'实验室','实验室');

/*Table structure for table `sprki_labthink_device_kind` */

DROP TABLE IF EXISTS `sprki_labthink_device_kind`;

CREATE TABLE `sprki_labthink_device_kind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_kind_name` varchar(100) NOT NULL,
  `enable` bit(1) NOT NULL,
  `device_kind_namecn` varchar(100) NOT NULL,
  `device_kind_nameen` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_labthink_device_kind` */

insert  into `sprki_labthink_device_kind` values (1,'national','','国标设备',''),(2,'international','','美标设备','');

/*Table structure for table `sprki_labthink_device_type` */

DROP TABLE IF EXISTS `sprki_labthink_device_type`;

CREATE TABLE `sprki_labthink_device_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_type_name` varchar(100) NOT NULL,
  `enable` bit(1) NOT NULL,
  `device_type_namecn` varchar(100) NOT NULL,
  `device_type_nameen` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_labthink_device_type` */

insert  into `sprki_labthink_device_type` values (1,'permebality','','阻隔性',''),(2,'strength','','力值设备','');

/*Table structure for table `sprki_labthink_devices` */

DROP TABLE IF EXISTS `sprki_labthink_devices`;

CREATE TABLE `sprki_labthink_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `devicename` varchar(100) NOT NULL,
  `device_kind` int(11) NOT NULL,
  `device_type` int(11) NOT NULL,
  `devicenamecn` varchar(100) NOT NULL,
  `devicenameen` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_c4hqbke2teisuu7lbpjtcpxbj` (`device_kind`),
  KEY `FK_hvlqj0cn7hnu9tkg0udtocnun` (`device_type`),
  CONSTRAINT `FK_c4hqbke2teisuu7lbpjtcpxbj` FOREIGN KEY (`device_kind`) REFERENCES `sprki_labthink_device_kind` (`id`),
  CONSTRAINT `FK_hvlqj0cn7hnu9tkg0udtocnun` FOREIGN KEY (`device_type`) REFERENCES `sprki_labthink_device_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sprki_labthink_devices` */

insert  into `sprki_labthink_devices` values (1,'W3/330',1,1,'',''),(2,'氧透过',2,2,'','');

/*Table structure for table `sprki_labthink_image_url` */

DROP TABLE IF EXISTS `sprki_labthink_image_url`;

CREATE TABLE `sprki_labthink_image_url` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_url_name` varchar(80) NOT NULL,
  `image_url_namecn` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_labthink_image_url` */

/*Table structure for table `sprki_user` */

DROP TABLE IF EXISTS `sprki_user`;

CREATE TABLE `sprki_user` (
  `username` varchar(30) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `password` varchar(50) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username_alias` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sprki_user` */

insert  into `sprki_user` values ('11122','\0','222','2016-03-29 13:25:15','11122'),('aaa','','aaa','2016-02-25 08:56:04','1'),('admin','','admin','2016-02-17 00:00:00','admin'),('bbb','','bbb','2016-02-17 00:00:00','b'),('user','','user','2016-02-17 00:00:00','user');

/*Table structure for table `test_address` */

DROP TABLE IF EXISTS `test_address`;

CREATE TABLE `test_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `street` varchar(255) DEFAULT NULL,
  `town` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_4xy1r0jj687l3c6n5181pmk2w` (`town`),
  CONSTRAINT `FK_4xy1r0jj687l3c6n5181pmk2w` FOREIGN KEY (`town`) REFERENCES `test_town` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1042 DEFAULT CHARSET=utf8;

/*Data for the table `test_address` */

insert  into `test_address` values (505,'257-5409 Orci, St.',505),(506,'P.O. Box 727, 8117 Elementum, Rd.',506),(507,'309-4063 Imperdiet Road',507),(508,'P.O. Box 953, 2116 Ornare, Street',508),(509,'Ap #917-606 Donec Road',509),(510,'Ap #987-9308 Primis Ave',510),(511,'2249 Eu, Road',511),(512,'P.O. Box 118, 2722 Non, Avenue',512),(513,'Ap #681-1822 A, St.',513),(514,'Ap #291-5907 Et St.',514),(515,'257-5409 Orci, St.',515),(516,'P.O. Box 727, 8117 Elementum, Rd.',516),(517,'309-4063 Imperdiet Road',517),(518,'P.O. Box 953, 2116 Ornare, Street',518),(519,'Ap #917-606 Donec Road',519),(520,'Ap #987-9308 Primis Ave',520),(521,'2249 Eu, Road',521),(522,'P.O. Box 118, 2722 Non, Avenue',522),(523,'Ap #681-1822 A, St.',523),(524,'Ap #291-5907 Et St.',524),(525,'257-5409 Orci, St.',525),(526,'257-5409 Orci, St.',526),(527,'257-5409 Orci, St.',527),(528,'257-5409 Orci, St.',528),(529,'257-5409 Orci, St.',529),(530,'257-5409 Orci, St.',530),(531,'257-5409 Orci, St.',531),(532,'257-5409 Orci, St.',532),(533,'P.O. Box 727, 8117 Elementum, Rd.',533),(534,'309-4063 Imperdiet Road',534),(535,'P.O. Box 953, 2116 Ornare, Street',535),(536,'Ap #917-606 Donec Road',536),(537,'Ap #987-9308 Primis Ave',537),(538,'2249 Eu, Road',538),(539,'P.O. Box 118, 2722 Non, Avenue',539),(540,'Ap #681-1822 A, St.',540),(541,'Ap #291-5907 Et St.',541),(542,'257-5409 Orci, St.',542),(543,'P.O. Box 727, 8117 Elementum, Rd.',543),(544,'309-4063 Imperdiet Road',544),(545,'P.O. Box 953, 2116 Ornare, Street',545),(546,'Ap #917-606 Donec Road',546),(547,'Ap #987-9308 Primis Ave',547),(548,'2249 Eu, Road',548),(549,'P.O. Box 118, 2722 Non, Avenue',549),(550,'Ap #681-1822 A, St.',550),(551,'Ap #291-5907 Et St.',551),(552,'116-6304 Per St.',552),(553,'403-5307 Non, Ave',553),(554,'Ap #568-1343 Bibendum St.',554),(555,'5015 Malesuada Rd.',555),(556,'P.O. Box 264, 8113 Leo St.',556),(557,'Ap #821-7906 Aliquet. Road',557),(558,'266-5244 Vestibulum, St.',558),(559,'P.O. Box 834, 7013 Urna. St.',559),(560,'Ap #539-5122 Ipsum. Rd.',560),(561,'P.O. Box 750, 8405 Nascetur Rd.',561),(562,'546-4157 Morbi Rd.',562),(563,'565-336 Risus. Av.',563),(564,'P.O. Box 625, 5563 Ligula Ave',564),(565,'P.O. Box 968, 9827 Lacus. Rd.',565),(566,'352-3929 Cursus. Rd.',566),(567,'7451 Iaculis Road',567),(568,'1116 Conubia Avenue',568),(569,'P.O. Box 773, 8634 Eget St.',569),(570,'6853 Vel Road',570),(571,'9480 Amet Rd.',571),(572,'P.O. Box 946, 6054 Cras Road',572),(573,'P.O. Box 248, 7231 Tellus. Rd.',573),(574,'520-9501 Orci. Av.',574),(575,'5529 Sed Av.',575),(576,'P.O. Box 985, 8791 Libero Street',576),(577,'Ap #357-6116 Ante. Rd.',577),(578,'3504 Et Avenue',578),(579,'570 Elit. St.',579),(580,'9306 Pharetra. Rd.',580),(581,'887-5566 Ridiculus Ave',581),(582,'129-4727 Lacus. Rd.',582),(583,'Ap #217-6454 Massa Ave',583),(584,'950-595 Eu, Avenue',584),(585,'5117 Velit Avenue',585),(586,'509-5206 Nisl. Street',586),(587,'588-4181 Aliquam St.',587),(588,'7666 Et Road',588),(589,'Ap #131-3980 Aliquam Road',589),(590,'974-3856 Imperdiet Road',590),(591,'7182 Orci. St.',591),(592,'2991 Tincidunt Street',592),(593,'Ap #568-8469 Eu, Av.',593),(594,'P.O. Box 595, 257 Tempus Rd.',594),(595,'Ap #608-8513 Consectetuer, Road',595),(596,'P.O. Box 113, 3895 Ultricies Street',596),(597,'P.O. Box 965, 8379 Ultrices Avenue',597),(598,'898-5437 Non St.',598),(599,'Ap #124-5651 Vel, St.',599),(600,'P.O. Box 218, 7143 Magna St.',600),(601,'184-2705 Sed, Street',601),(602,'Ap #229-9559 Nec, Avenue',602),(603,'907-696 Leo, St.',603),(604,'P.O. Box 807, 542 Rutrum. St.',604),(605,'Ap #752-7793 Nec Rd.',605),(606,'Ap #101-9149 Consequat Av.',606),(607,'2415 Non, Avenue',607),(608,'Ap #147-1269 Integer Ave',608),(609,'Ap #217-1175 Eget St.',609),(610,'8228 At Ave',610),(611,'3891 Cras Rd.',611),(612,'453-309 Lectus Road',612),(613,'276-9227 Facilisis Street',613),(614,'425-1569 Luctus St.',614),(615,'701-9273 Semper, Street',615),(616,'967 Donec Street',616),(617,'Ap #699-8393 Non Rd.',617),(618,'948-3235 Auctor St.',618),(619,'Ap #914-6412 In, St.',619),(620,'Ap #379-9918 Mauris, Rd.',620),(621,'Ap #586-1644 Amet Street',621),(622,'280-1136 Quis, Road',622),(623,'P.O. Box 484, 7373 Quis Av.',623),(624,'Ap #649-5086 Commodo Rd.',624),(625,'P.O. Box 334, 8680 Aliquam Rd.',625),(626,'306-6471 Sed St.',626),(627,'3748 Et Street',627),(628,'Ap #784-7512 Aliquam Rd.',628),(629,'1031 Urna, Street',629),(630,'334-1629 Hendrerit. Rd.',630),(631,'119-1333 Montes, St.',631),(632,'P.O. Box 367, 606 Eget, Ave',632),(633,'2022 Placerat, Rd.',633),(634,'P.O. Box 308, 2363 Pede Avenue',634),(635,'9242 Natoque Street',635),(636,'P.O. Box 598, 1081 Nulla St.',636),(637,'843-9920 Nam Street',637),(638,'810-5825 Donec St.',638),(639,'P.O. Box 933, 9940 Dolor. Ave',639),(640,'Ap #474-9684 Mauris St.',640),(641,'Ap #291-5592 Vivamus St.',641),(642,'257-5409 Orci, St.',642),(643,'P.O. Box 727, 8117 Elementum, Rd.',643),(644,'309-4063 Imperdiet Road',644),(645,'P.O. Box 953, 2116 Ornare, Street',645),(646,'Ap #917-606 Donec Road',646),(647,'Ap #987-9308 Primis Ave',647),(648,'2249 Eu, Road',648),(649,'P.O. Box 118, 2722 Non, Avenue',649),(650,'Ap #681-1822 A, St.',650),(651,'Ap #291-5907 Et St.',651),(652,'116-6304 Per St.',652),(653,'403-5307 Non, Ave',653),(654,'Ap #568-1343 Bibendum St.',654),(655,'5015 Malesuada Rd.',655),(656,'P.O. Box 264, 8113 Leo St.',656),(657,'Ap #821-7906 Aliquet. Road',657),(658,'266-5244 Vestibulum, St.',658),(659,'P.O. Box 834, 7013 Urna. St.',659),(660,'Ap #539-5122 Ipsum. Rd.',660),(661,'P.O. Box 750, 8405 Nascetur Rd.',661),(662,'546-4157 Morbi Rd.',662),(663,'565-336 Risus. Av.',663),(664,'P.O. Box 625, 5563 Ligula Ave',664),(665,'P.O. Box 968, 9827 Lacus. Rd.',665),(666,'352-3929 Cursus. Rd.',666),(667,'7451 Iaculis Road',667),(668,'1116 Conubia Avenue',668),(669,'P.O. Box 773, 8634 Eget St.',669),(670,'6853 Vel Road',670),(671,'9480 Amet Rd.',671),(672,'P.O. Box 946, 6054 Cras Road',672),(673,'P.O. Box 248, 7231 Tellus. Rd.',673),(674,'520-9501 Orci. Av.',674),(675,'5529 Sed Av.',675),(676,'P.O. Box 985, 8791 Libero Street',676),(677,'Ap #357-6116 Ante. Rd.',677),(678,'3504 Et Avenue',678),(679,'570 Elit. St.',679),(680,'9306 Pharetra. Rd.',680),(681,'887-5566 Ridiculus Ave',681),(682,'129-4727 Lacus. Rd.',682),(683,'Ap #217-6454 Massa Ave',683),(684,'950-595 Eu, Avenue',684),(685,'5117 Velit Avenue',685),(686,'509-5206 Nisl. Street',686),(687,'588-4181 Aliquam St.',687),(688,'7666 Et Road',688),(689,'Ap #131-3980 Aliquam Road',689),(690,'974-3856 Imperdiet Road',690),(691,'7182 Orci. St.',691),(692,'2991 Tincidunt Street',692),(693,'Ap #568-8469 Eu, Av.',693),(694,'P.O. Box 595, 257 Tempus Rd.',694),(695,'Ap #608-8513 Consectetuer, Road',695),(696,'P.O. Box 113, 3895 Ultricies Street',696),(697,'P.O. Box 965, 8379 Ultrices Avenue',697),(698,'898-5437 Non St.',698),(699,'Ap #124-5651 Vel, St.',699),(700,'P.O. Box 218, 7143 Magna St.',700),(701,'184-2705 Sed, Street',701),(702,'Ap #229-9559 Nec, Avenue',702),(703,'907-696 Leo, St.',703),(704,'P.O. Box 807, 542 Rutrum. St.',704),(705,'Ap #752-7793 Nec Rd.',705),(706,'Ap #101-9149 Consequat Av.',706),(707,'2415 Non, Avenue',707),(708,'Ap #147-1269 Integer Ave',708),(709,'Ap #217-1175 Eget St.',709),(710,'8228 At Ave',710),(711,'3891 Cras Rd.',711),(712,'453-309 Lectus Road',712),(713,'276-9227 Facilisis Street',713),(714,'425-1569 Luctus St.',714),(715,'701-9273 Semper, Street',715),(716,'967 Donec Street',716),(717,'Ap #699-8393 Non Rd.',717),(718,'948-3235 Auctor St.',718),(719,'Ap #914-6412 In, St.',719),(720,'Ap #379-9918 Mauris, Rd.',720),(721,'Ap #586-1644 Amet Street',721),(722,'280-1136 Quis, Road',722),(723,'P.O. Box 484, 7373 Quis Av.',723),(724,'Ap #649-5086 Commodo Rd.',724),(725,'P.O. Box 334, 8680 Aliquam Rd.',725),(726,'306-6471 Sed St.',726),(727,'3748 Et Street',727),(728,'Ap #784-7512 Aliquam Rd.',728),(729,'1031 Urna, Street',729),(730,'334-1629 Hendrerit. Rd.',730),(731,'119-1333 Montes, St.',731),(732,'P.O. Box 367, 606 Eget, Ave',732),(733,'2022 Placerat, Rd.',733),(734,'P.O. Box 308, 2363 Pede Avenue',734),(735,'9242 Natoque Street',735),(736,'P.O. Box 598, 1081 Nulla St.',736),(737,'843-9920 Nam Street',737),(738,'810-5825 Donec St.',738),(739,'P.O. Box 933, 9940 Dolor. Ave',739),(740,'Ap #474-9684 Mauris St.',740),(741,'Ap #291-5592 Vivamus St.',741),(742,'257-5409 Orci, St.',742),(743,'P.O. Box 727, 8117 Elementum, Rd.',743),(744,'309-4063 Imperdiet Road',744),(745,'P.O. Box 953, 2116 Ornare, Street',745),(746,'Ap #917-606 Donec Road',746),(747,'Ap #987-9308 Primis Ave',747),(748,'2249 Eu, Road',748),(749,'P.O. Box 118, 2722 Non, Avenue',749),(750,'Ap #681-1822 A, St.',750),(751,'Ap #291-5907 Et St.',751),(752,'116-6304 Per St.',752),(753,'403-5307 Non, Ave',753),(754,'Ap #568-1343 Bibendum St.',754),(755,'5015 Malesuada Rd.',755),(756,'P.O. Box 264, 8113 Leo St.',756),(757,'Ap #821-7906 Aliquet. Road',757),(758,'266-5244 Vestibulum, St.',758),(759,'P.O. Box 834, 7013 Urna. St.',759),(760,'Ap #539-5122 Ipsum. Rd.',760),(761,'P.O. Box 750, 8405 Nascetur Rd.',761),(762,'546-4157 Morbi Rd.',762),(763,'565-336 Risus. Av.',763),(764,'P.O. Box 625, 5563 Ligula Ave',764),(765,'P.O. Box 968, 9827 Lacus. Rd.',765),(766,'352-3929 Cursus. Rd.',766),(767,'7451 Iaculis Road',767),(768,'1116 Conubia Avenue',768),(769,'P.O. Box 773, 8634 Eget St.',769),(770,'6853 Vel Road',770),(771,'9480 Amet Rd.',771),(772,'P.O. Box 946, 6054 Cras Road',772),(773,'P.O. Box 248, 7231 Tellus. Rd.',773),(774,'520-9501 Orci. Av.',774),(775,'5529 Sed Av.',775),(776,'P.O. Box 985, 8791 Libero Street',776),(777,'Ap #357-6116 Ante. Rd.',777),(778,'3504 Et Avenue',778),(779,'570 Elit. St.',779),(780,'9306 Pharetra. Rd.',780),(781,'887-5566 Ridiculus Ave',781),(782,'129-4727 Lacus. Rd.',782),(783,'Ap #217-6454 Massa Ave',783),(784,'950-595 Eu, Avenue',784),(785,'5117 Velit Avenue',785),(786,'509-5206 Nisl. Street',786),(787,'588-4181 Aliquam St.',787),(788,'7666 Et Road',788),(789,'Ap #131-3980 Aliquam Road',789),(790,'974-3856 Imperdiet Road',790),(791,'7182 Orci. St.',791),(792,'2991 Tincidunt Street',792),(793,'Ap #568-8469 Eu, Av.',793),(794,'P.O. Box 595, 257 Tempus Rd.',794),(795,'Ap #608-8513 Consectetuer, Road',795),(796,'P.O. Box 113, 3895 Ultricies Street',796),(797,'P.O. Box 965, 8379 Ultrices Avenue',797),(798,'898-5437 Non St.',798),(799,'Ap #124-5651 Vel, St.',799),(800,'P.O. Box 218, 7143 Magna St.',800),(801,'184-2705 Sed, Street',801),(802,'Ap #229-9559 Nec, Avenue',802),(803,'907-696 Leo, St.',803),(804,'P.O. Box 807, 542 Rutrum. St.',804),(805,'Ap #752-7793 Nec Rd.',805),(806,'Ap #101-9149 Consequat Av.',806),(807,'2415 Non, Avenue',807),(808,'Ap #147-1269 Integer Ave',808),(809,'Ap #217-1175 Eget St.',809),(810,'8228 At Ave',810),(811,'3891 Cras Rd.',811),(812,'453-309 Lectus Road',812),(813,'276-9227 Facilisis Street',813),(814,'425-1569 Luctus St.',814),(815,'701-9273 Semper, Street',815),(816,'967 Donec Street',816),(817,'Ap #699-8393 Non Rd.',817),(818,'948-3235 Auctor St.',818),(819,'Ap #914-6412 In, St.',819),(820,'Ap #379-9918 Mauris, Rd.',820),(821,'Ap #586-1644 Amet Street',821),(822,'280-1136 Quis, Road',822),(823,'P.O. Box 484, 7373 Quis Av.',823),(824,'Ap #649-5086 Commodo Rd.',824),(825,'P.O. Box 334, 8680 Aliquam Rd.',825),(826,'306-6471 Sed St.',826),(827,'3748 Et Street',827),(828,'Ap #784-7512 Aliquam Rd.',828),(829,'1031 Urna, Street',829),(830,'334-1629 Hendrerit. Rd.',830),(831,'119-1333 Montes, St.',831),(832,'P.O. Box 367, 606 Eget, Ave',832),(833,'2022 Placerat, Rd.',833),(834,'P.O. Box 308, 2363 Pede Avenue',834),(835,'9242 Natoque Street',835),(836,'P.O. Box 598, 1081 Nulla St.',836),(837,'843-9920 Nam Street',837),(838,'810-5825 Donec St.',838),(839,'P.O. Box 933, 9940 Dolor. Ave',839),(840,'Ap #474-9684 Mauris St.',840),(841,'Ap #291-5592 Vivamus St.',841),(842,'257-5409 Orci, St.',842),(843,'P.O. Box 727, 8117 Elementum, Rd.',843),(844,'309-4063 Imperdiet Road',844),(845,'P.O. Box 953, 2116 Ornare, Street',845),(846,'Ap #917-606 Donec Road',846),(847,'Ap #987-9308 Primis Ave',847),(848,'2249 Eu, Road',848),(849,'P.O. Box 118, 2722 Non, Avenue',849),(850,'Ap #681-1822 A, St.',850),(851,'Ap #291-5907 Et St.',851),(852,'116-6304 Per St.',852),(853,'403-5307 Non, Ave',853),(854,'Ap #568-1343 Bibendum St.',854),(855,'5015 Malesuada Rd.',855),(856,'P.O. Box 264, 8113 Leo St.',856),(857,'Ap #821-7906 Aliquet. Road',857),(858,'266-5244 Vestibulum, St.',858),(859,'P.O. Box 834, 7013 Urna. St.',859),(860,'Ap #539-5122 Ipsum. Rd.',860),(861,'P.O. Box 750, 8405 Nascetur Rd.',861),(862,'546-4157 Morbi Rd.',862),(863,'565-336 Risus. Av.',863),(864,'P.O. Box 625, 5563 Ligula Ave',864),(865,'P.O. Box 968, 9827 Lacus. Rd.',865),(866,'352-3929 Cursus. Rd.',866),(867,'7451 Iaculis Road',867),(868,'1116 Conubia Avenue',868),(869,'P.O. Box 773, 8634 Eget St.',869),(870,'6853 Vel Road',870),(871,'9480 Amet Rd.',871),(872,'P.O. Box 946, 6054 Cras Road',872),(873,'P.O. Box 248, 7231 Tellus. Rd.',873),(874,'520-9501 Orci. Av.',874),(875,'5529 Sed Av.',875),(876,'P.O. Box 985, 8791 Libero Street',876),(877,'Ap #357-6116 Ante. Rd.',877),(878,'3504 Et Avenue',878),(879,'570 Elit. St.',879),(880,'9306 Pharetra. Rd.',880),(881,'887-5566 Ridiculus Ave',881),(882,'129-4727 Lacus. Rd.',882),(883,'Ap #217-6454 Massa Ave',883),(884,'950-595 Eu, Avenue',884),(885,'5117 Velit Avenue',885),(886,'509-5206 Nisl. Street',886),(887,'588-4181 Aliquam St.',887),(888,'7666 Et Road',888),(889,'Ap #131-3980 Aliquam Road',889),(890,'974-3856 Imperdiet Road',890),(891,'7182 Orci. St.',891),(892,'2991 Tincidunt Street',892),(893,'Ap #568-8469 Eu, Av.',893),(894,'P.O. Box 595, 257 Tempus Rd.',894),(895,'Ap #608-8513 Consectetuer, Road',895),(896,'P.O. Box 113, 3895 Ultricies Street',896),(897,'P.O. Box 965, 8379 Ultrices Avenue',897),(898,'898-5437 Non St.',898),(899,'Ap #124-5651 Vel, St.',899),(900,'P.O. Box 218, 7143 Magna St.',900),(901,'184-2705 Sed, Street',901),(902,'Ap #229-9559 Nec, Avenue',902),(903,'907-696 Leo, St.',903),(904,'P.O. Box 807, 542 Rutrum. St.',904),(905,'Ap #752-7793 Nec Rd.',905),(906,'Ap #101-9149 Consequat Av.',906),(907,'2415 Non, Avenue',907),(908,'Ap #147-1269 Integer Ave',908),(909,'Ap #217-1175 Eget St.',909),(910,'8228 At Ave',910),(911,'3891 Cras Rd.',911),(912,'453-309 Lectus Road',912),(913,'276-9227 Facilisis Street',913),(914,'425-1569 Luctus St.',914),(915,'701-9273 Semper, Street',915),(916,'967 Donec Street',916),(917,'Ap #699-8393 Non Rd.',917),(918,'948-3235 Auctor St.',918),(919,'Ap #914-6412 In, St.',919),(920,'Ap #379-9918 Mauris, Rd.',920),(921,'Ap #586-1644 Amet Street',921),(922,'280-1136 Quis, Road',922),(923,'P.O. Box 484, 7373 Quis Av.',923),(924,'Ap #649-5086 Commodo Rd.',924),(925,'P.O. Box 334, 8680 Aliquam Rd.',925),(926,'306-6471 Sed St.',926),(927,'3748 Et Street',927),(928,'Ap #784-7512 Aliquam Rd.',928),(929,'1031 Urna, Street',929),(930,'334-1629 Hendrerit. Rd.',930),(931,'119-1333 Montes, St.',931),(932,'P.O. Box 367, 606 Eget, Ave',932),(933,'2022 Placerat, Rd.',933),(934,'P.O. Box 308, 2363 Pede Avenue',934),(935,'9242 Natoque Street',935),(936,'P.O. Box 598, 1081 Nulla St.',936),(937,'843-9920 Nam Street',937),(938,'810-5825 Donec St.',938),(939,'P.O. Box 933, 9940 Dolor. Ave',939),(940,'Ap #474-9684 Mauris St.',940),(941,'Ap #291-5592 Vivamus St.',941),(942,'257-5409 Orci, St.',942),(943,'P.O. Box 727, 8117 Elementum, Rd.',943),(944,'309-4063 Imperdiet Road',944),(945,'P.O. Box 953, 2116 Ornare, Street',945),(946,'Ap #917-606 Donec Road',946),(947,'Ap #987-9308 Primis Ave',947),(948,'2249 Eu, Road',948),(949,'P.O. Box 118, 2722 Non, Avenue',949),(950,'Ap #681-1822 A, St.',950),(951,'Ap #291-5907 Et St.',951),(952,'116-6304 Per St.',952),(953,'403-5307 Non, Ave',953),(954,'Ap #568-1343 Bibendum St.',954),(955,'5015 Malesuada Rd.',955),(956,'P.O. Box 264, 8113 Leo St.',956),(957,'Ap #821-7906 Aliquet. Road',957),(958,'266-5244 Vestibulum, St.',958),(959,'P.O. Box 834, 7013 Urna. St.',959),(960,'Ap #539-5122 Ipsum. Rd.',960),(961,'P.O. Box 750, 8405 Nascetur Rd.',961),(962,'546-4157 Morbi Rd.',962),(963,'565-336 Risus. Av.',963),(964,'P.O. Box 625, 5563 Ligula Ave',964),(965,'P.O. Box 968, 9827 Lacus. Rd.',965),(966,'352-3929 Cursus. Rd.',966),(967,'7451 Iaculis Road',967),(968,'1116 Conubia Avenue',968),(969,'P.O. Box 773, 8634 Eget St.',969),(970,'6853 Vel Road',970),(971,'9480 Amet Rd.',971),(972,'P.O. Box 946, 6054 Cras Road',972),(973,'P.O. Box 248, 7231 Tellus. Rd.',973),(974,'520-9501 Orci. Av.',974),(975,'5529 Sed Av.',975),(976,'P.O. Box 985, 8791 Libero Street',976),(977,'Ap #357-6116 Ante. Rd.',977),(978,'3504 Et Avenue',978),(979,'570 Elit. St.',979),(980,'9306 Pharetra. Rd.',980),(981,'887-5566 Ridiculus Ave',981),(982,'129-4727 Lacus. Rd.',982),(983,'Ap #217-6454 Massa Ave',983),(984,'950-595 Eu, Avenue',984),(985,'5117 Velit Avenue',985),(986,'509-5206 Nisl. Street',986),(987,'588-4181 Aliquam St.',987),(988,'7666 Et Road',988),(989,'Ap #131-3980 Aliquam Road',989),(990,'974-3856 Imperdiet Road',990),(991,'7182 Orci. St.',991),(992,'2991 Tincidunt Street',992),(993,'Ap #568-8469 Eu, Av.',993),(994,'P.O. Box 595, 257 Tempus Rd.',994),(995,'Ap #608-8513 Consectetuer, Road',995),(996,'P.O. Box 113, 3895 Ultricies Street',996),(997,'P.O. Box 965, 8379 Ultrices Avenue',997),(998,'898-5437 Non St.',998),(999,'Ap #124-5651 Vel, St.',999),(1000,'P.O. Box 218, 7143 Magna St.',1000),(1001,'184-2705 Sed, Street',1001),(1002,'Ap #229-9559 Nec, Avenue',1002),(1003,'907-696 Leo, St.',1003),(1004,'P.O. Box 807, 542 Rutrum. St.',1004),(1005,'Ap #752-7793 Nec Rd.',1005),(1006,'Ap #101-9149 Consequat Av.',1006),(1007,'2415 Non, Avenue',1007),(1008,'Ap #147-1269 Integer Ave',1008),(1009,'Ap #217-1175 Eget St.',1009),(1010,'8228 At Ave',1010),(1011,'3891 Cras Rd.',1011),(1012,'453-309 Lectus Road',1012),(1013,'276-9227 Facilisis Street',1013),(1014,'425-1569 Luctus St.',1014),(1015,'701-9273 Semper, Street',1015),(1016,'967 Donec Street',1016),(1017,'Ap #699-8393 Non Rd.',1017),(1018,'948-3235 Auctor St.',1018),(1019,'Ap #914-6412 In, St.',1019),(1020,'Ap #379-9918 Mauris, Rd.',1020),(1021,'Ap #586-1644 Amet Street',1021),(1022,'280-1136 Quis, Road',1022),(1023,'P.O. Box 484, 7373 Quis Av.',1023),(1024,'Ap #649-5086 Commodo Rd.',1024),(1025,'P.O. Box 334, 8680 Aliquam Rd.',1025),(1026,'306-6471 Sed St.',1026),(1027,'3748 Et Street',1027),(1028,'Ap #784-7512 Aliquam Rd.',1028),(1029,'1031 Urna, Street',1029),(1030,'334-1629 Hendrerit. Rd.',1030),(1031,'119-1333 Montes, St.',1031),(1032,'P.O. Box 367, 606 Eget, Ave',1032),(1033,'2022 Placerat, Rd.',1033),(1034,'P.O. Box 308, 2363 Pede Avenue',1034),(1035,'9242 Natoque Street',1035),(1036,'P.O. Box 598, 1081 Nulla St.',1036),(1037,'843-9920 Nam Street',1037),(1038,'810-5825 Donec St.',1038),(1039,'P.O. Box 933, 9940 Dolor. Ave',1039),(1040,'Ap #474-9684 Mauris St.',1040),(1041,'Ap #291-5592 Vivamus St.',1041);

/*Table structure for table `test_company` */

DROP TABLE IF EXISTS `test_company`;

CREATE TABLE `test_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `test_company` */

insert  into `test_company` values (1,'Google'),(2,'Facebook'),(3,'Yahoo!'),(4,'Intel'),(5,'Microsoft'),(6,'Amazon'),(7,'Twitter'),(8,'Apple');

/*Table structure for table `test_person` */

DROP TABLE IF EXISTS `test_person`;

CREATE TABLE `test_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `birth_date` datetime DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `address` bigint(20) NOT NULL,
  `company` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mm1ittwe9alq1pwbkluabrkcu` (`address`),
  KEY `FK_2bt4mrlv0ata94jjrfa7am99b` (`company`),
  CONSTRAINT `FK_2bt4mrlv0ata94jjrfa7am99b` FOREIGN KEY (`company`) REFERENCES `test_company` (`id`),
  CONSTRAINT `FK_mm1ittwe9alq1pwbkluabrkcu` FOREIGN KEY (`address`) REFERENCES `test_address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;

/*Data for the table `test_person` */

insert  into `test_person` values (2,'1989-10-27 00:00:00','Karleigh','Merritt','Morbi.metus@diamlorem.com','56,911',943,2),(3,'2006-11-11 00:00:00','Marah','Livingston','Praesent.luctus@nasceturridiculusmus.ca','91,433',944,3),(4,'1992-01-29 00:00:00','Mannix','Hartman','ipsum.primis.in@noncursusnon.org','447,333',945,3),(5,'2003-02-17 00:00:00','Cedric','Forbes','In.at.pede@mattis.com','328,439',946,4),(6,'1983-01-31 00:00:00','Dennis','Marshall','vel.turpis.Aliquam@dignissimpharetra.net','426,014',947,4),(7,'1981-09-07 00:00:00','Heidi','Hooper','Nullam.ut.nisi@imperdiet.co.uk','6,778',948,4),(8,'1981-07-05 00:00:00','Kerry','Zamora','vel.vulputate@cubiliaCurae.co.uk','57,563',949,2),(9,'2007-01-18 00:00:00','Kylie','Reeves','purus@ante.co.uk','106,924',950,5),(10,'2003-05-13 00:00:00','Patricia','Pate','erat.Sed.nunc@loremvehicula.edu','434,381',951,6),(11,'2005-07-07 00:00:00','Lester','Miles','consequat.purus@cursusdiam.net','113,387',952,1),(12,'1988-01-20 00:00:00','Brenden','Velazquez','felis.Donec@acfermentum.net','188,688',953,7),(13,'1993-08-08 00:00:00','Althea','White','orci@Mauris.ca','481,710',954,1),(14,'1995-05-02 00:00:00','Theodore','Arnold','bibendum.ullamcorper@Aliquamgravidamauris.edu','401,353',955,5),(15,'2013-06-15 00:00:00','Isaiah','Moreno','semper@velitin.com','325,617',956,7),(16,'2013-01-03 00:00:00','Aretha','Castaneda','Phasellus.vitae@anuncIn.ca','403,486',957,7),(17,'1979-07-09 00:00:00','Tana','Turner','pede@adipiscing.com','190,875',958,3),(18,'2006-04-12 00:00:00','Britanney','Farley','condimentum@pedesagittis.net','198,143',959,3),(19,'2012-10-04 00:00:00','Jayme','Landry','rutrum.non@Donecfelis.edu','17,666',960,8),(20,'1997-11-26 00:00:00','Desirae','Sharpe','Vestibulum.ante.ipsum@porta.net','315,245',961,4),(21,'2007-02-11 00:00:00','Tana','Boone','mauris.eu@nostraper.org','369,608',962,7),(22,'1997-02-20 00:00:00','Lucian','Collins','Aenean.sed.pede@lacusQuisque.com','449,382',963,7),(23,'1988-05-24 00:00:00','Jennifer','Ortiz','nunc@sitametmassa.net','110,178',964,5),(24,'1984-06-15 00:00:00','Harding','Mathews','dui@sagittislobortis.edu','56,620',965,2),(25,'2005-02-08 00:00:00','Winter','Fleming','sit@mauris.ca','235,543',966,6),(26,'1995-04-06 00:00:00','Nora','Mills','Sed.nunc.est@Sedetlibero.com','342,761',967,8),(27,'2006-03-18 00:00:00','Victoria','Little','sem.ut@vitae.com','205,711',968,4),(28,'1993-03-20 00:00:00','Noah','Nunez','non.lacinia@duiCumsociis.net','484,778',969,3),(29,'1987-10-12 00:00:00','Yardley','Witt','est.Nunc.ullamcorper@In.ca','115,540',970,5),(30,'1979-09-24 00:00:00','Bryar','Kennedy','eleifend@euduiCum.edu','155,180',971,1),(31,'1987-04-15 00:00:00','Scarlett','Conway','consectetuer.ipsum@enimconsequatpurus.org','100,678',972,7),(32,'2008-06-12 00:00:00','Burke','Beach','convallis@dui.co.uk','143,103',973,6),(33,'1983-07-21 00:00:00','Lois','Contreras','nascetur.ridiculus.mus@tincidunttempusrisus.org','183,988',974,7),(34,'2013-05-09 00:00:00','Dieter','Wyatt','porta@maurisMorbi.com','266,628',975,2),(35,'2009-01-20 00:00:00','Armand','Juarez','eu.tellus@Utsemperpretium.ca','55,133',976,1),(36,'1989-03-20 00:00:00','Travis','Byrd','Donec.tincidunt.Donec@consequat.ca','161,961',977,6),(37,'1999-08-27 00:00:00','Carter','Sharp','nec.enim@nibhdolornonummy.com','373,678',978,6),(38,'1981-01-22 00:00:00','Lacy','Mann','Phasellus@Uttincidunt.edu','248,218',979,8),(39,'1994-07-31 00:00:00','Alan','Sawyer','tincidunt@Nuncpulvinararcu.ca','311,884',980,6),(40,'1987-12-12 00:00:00','Deanna','Roman','fermentum.vel.mauris@Cum.org','187,944',981,2),(41,'1991-11-26 00:00:00','Kirsten','Hodges','enim@Aliquamornarelibero.edu','289,431',982,6),(42,'2013-07-29 00:00:00','Ria','Burns','id.mollis.nec@Morbiquis.com','200,258',983,5),(43,'1991-01-01 00:00:00','Lucy','David','molestie@inconsequat.com','410,521',984,2),(44,'1998-05-20 00:00:00','Jane','Walters','rutrum.urna@enimnisl.net','382,567',985,5),(45,'2006-07-14 00:00:00','Winter','Bauer','turpis.egestas@pellentesqueegetdictum.net','240,123',986,2),(46,'1985-07-05 00:00:00','Rae','Kirk','Proin@lorem.org','97,197',987,5),(47,'2001-07-29 00:00:00','India','Rosales','Sed.id.risus@sapiengravidanon.co.uk','22,430',988,3),(48,'1983-09-09 00:00:00','Jerry','Sherman','mattis.Integer.eu@lobortis.org','271,536',989,2),(49,'2005-06-10 00:00:00','Calista','Mcknight','Aliquam.erat.volutpat@leoVivamus.org','192,168',990,2),(50,'1990-11-12 00:00:00','Camilla','Donovan','sociis.natoque.penatibus@eliterat.ca','412,751',991,7),(51,'1980-04-14 00:00:00','Myra','Ochoa','purus@fermentumfermentum.edu','497,360',992,6),(52,'2006-07-16 00:00:00','Ignacia','Maynard','Donec.at@condimentum.net','194,288',993,7),(53,'2006-07-18 00:00:00','Melanie','Michael','venenatis@interdumNunc.ca','467,666',994,5),(54,'2007-04-28 00:00:00','Kimberly','Hester','nunc.est@vitaeodio.com','237,404',995,5),(55,'1998-08-26 00:00:00','Murphy','Heath','varius@nunc.com','117,651',996,3),(56,'1991-07-21 00:00:00','Aquila','Mejia','vehicula.Pellentesque.tincidunt@et.org','247,707',997,5),(57,'2005-04-16 00:00:00','Chiquita','Gibson','pede@luctus.com','233,358',998,4),(58,'2012-02-21 00:00:00','Dexter','Holman','consequat.dolor.vitae@nequevitaesemper.edu','133,150',999,6),(59,'1999-03-17 00:00:00','Lev','Valdez','vitae.aliquet@eratSed.net','356,870',1000,8),(60,'1998-08-02 00:00:00','Fletcher','Mayer','Phasellus@leoVivamus.co.uk','53,925',1001,6),(61,'1988-10-29 00:00:00','Yvette','Sweet','non@auctor.co.uk','281,864',1002,1),(62,'1990-06-20 00:00:00','Charles','Glover','Cras.interdum.Nunc@est.org','25,938',1003,2),(63,'1984-03-04 00:00:00','Armando','Macias','Suspendisse.commodo.tincidunt@duiFusce.com','140,190',1004,8),(64,'2000-06-02 00:00:00','Ina','Carey','ante.Vivamus.non@nisi.com','68,447',1005,1),(65,'1978-11-19 00:00:00','Lane','Payne','ipsum.Curabitur.consequat@dictumPhasellusin.ca','454,998',1006,6),(66,'1979-09-02 00:00:00','Jordan','Dillon','ultrices.a.auctor@luctusaliquet.edu','210,425',1007,5),(67,'2006-03-08 00:00:00','Germaine','Bishop','sed.dolor.Fusce@egetmetuseu.com','493,197',1008,2),(68,'1986-04-23 00:00:00','Derek','Rice','odio.tristique@pharetrasedhendrerit.edu','223,272',1009,6),(69,'2009-07-10 00:00:00','Maisie','Gamble','vulputate@atauctorullamcorper.ca','216,608',1010,1),(70,'1982-05-04 00:00:00','Tatyana','Green','quis.urna@turpis.org','218,614',1011,7),(71,'2003-07-12 00:00:00','Tashya','House','est.arcu.ac@tristiquesenectuset.org','233,800',1012,1),(72,'2009-09-25 00:00:00','Zelda','Franks','Cras.interdum.Nunc@acarcu.com','95,232',1013,6),(73,'1987-11-16 00:00:00','Zelda','Jacobs','eleifend@a.net','353,248',1014,5),(74,'1997-02-26 00:00:00','Gil','Schroeder','turpis@aliquetmagnaa.ca','331,788',1015,1),(75,'1989-11-14 00:00:00','Seth','Moore','pede.malesuada.vel@ac.org','244,850',1016,7),(76,'2004-04-14 00:00:00','Portia','Petersen','quis@pellentesqueSeddictum.net','165,533',1017,4),(77,'2002-02-25 00:00:00','Isabella','Sparks','neque.Sed@posuerevulputatelacus.com','274,771',1018,6),(78,'2001-10-27 00:00:00','Scott','Goodman','vitae.mauris@turpisNullaaliquet.edu','224,161',1019,7),(79,'1997-05-28 00:00:00','McKenzie','Gill','risus.Donec.egestas@sitamet.com','268,875',1020,3),(80,'1998-01-21 00:00:00','Avye','Goodman','erat@perinceptoshymenaeos.com','395,208',1021,8),(81,'2001-03-03 00:00:00','April','Curry','libero.mauris@blanditviverra.org','141,309',1022,8),(82,'1980-07-25 00:00:00','Haviva','Tanner','sed.libero.Proin@Crasdictum.org','484,002',1023,6),(83,'2002-12-15 00:00:00','Andrew','Morrow','et@ipsum.edu','225,043',1024,1),(84,'2004-12-27 00:00:00','Allen','Flores','Morbi@auctor.co.uk','438,249',1025,3),(85,'2011-08-16 00:00:00','Alea','Mcdonald','leo.Morbi.neque@facilisisSuspendissecommodo.net','104,329',1026,5),(86,'1979-06-05 00:00:00','Colleen','Duncan','a.auctor@musProin.ca','231,273',1027,1),(87,'1987-02-16 00:00:00','Gregory','Santiago','turpis@sitamet.co.uk','24,896',1028,5),(88,'2009-05-31 00:00:00','Macey','Farrell','massa.Quisque.porttitor@ultrices.com','492,470',1029,7),(89,'1994-04-27 00:00:00','Malik','Beasley','vel.sapien.imperdiet@Curabitur.co.uk','408,771',1030,6),(90,'1991-11-02 00:00:00','Amena','Duncan','eget@tempusrisusDonec.net','307,100',1031,8),(91,'2007-09-05 00:00:00','Neve','Bruce','in.faucibus@interdum.net','24,306',1032,4),(92,'1998-10-16 00:00:00','Jocelyn','Mcdonald','fermentum.fermentum.arcu@vitaediam.com','30,986',1033,2),(93,'1987-06-05 00:00:00','Adrian','Simon','et.euismod@faucibus.edu','75,419',1034,4),(94,'2005-11-19 00:00:00','Nell','Fuller','a.malesuada@augueSed.ca','424,604',1035,6),(95,'1993-09-24 00:00:00','Dolan','Oneill','vel.vulputate@Aliquamultrices.co.uk','380,525',1036,1),(96,'2006-05-14 00:00:00','Mannix','Owens','orci.Ut@nonummyutmolestie.com','301,668',1037,7),(97,'2010-06-27 00:00:00','Cody','Allison','Ut.semper.pretium@vehicula.com','330,813',1038,7),(98,'2009-11-20 00:00:00','Ryan','Jordan','nunc@nonummy.org','171,017',1039,8),(99,'1994-11-20 00:00:00','Montana','Hewitt','libero.mauris@orci.ca','397,716',1040,7),(100,'2012-05-28 00:00:00','Evelyn','Perkins','velit@lacinia.net','235,868',1041,4),(101,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',542,1),(102,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',642,1),(103,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',742,1),(104,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(105,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(106,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(107,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(108,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(109,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(110,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(111,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(112,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',842,1),(113,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',942,1),(114,'1992-06-20 00:00:00','Freya','Fischer','tincidunt.vehicula@accumsan.net','157,990',942,1);

/*Table structure for table `test_town` */

DROP TABLE IF EXISTS `test_town`;

CREATE TABLE `test_town` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1042 DEFAULT CHARSET=utf8;

/*Data for the table `test_town` */

insert  into `test_town` values (505,'Surrey','87682'),(506,'Cáceres','41401'),(507,'Signeulx','71949'),(508,'Herne','21810'),(509,'Madison','K1R 9B3'),(510,'Virginal-Samme','30532'),(511,'Sooke','24347'),(512,'Aserrí','1159'),(513,'Marilles','50484'),(514,'Whitewater Region Township','62245'),(515,'Surrey','87682'),(516,'Cáceres','41401'),(517,'Signeulx','71949'),(518,'Herne','21810'),(519,'Madison','K1R 9B3'),(520,'Virginal-Samme','30532'),(521,'Sooke','24347'),(522,'Aserrí','1159'),(523,'Marilles','50484'),(524,'Whitewater Region Township','62245'),(525,'Surrey','87682'),(526,'Surrey','87682'),(527,'Surrey','87682'),(528,'Surrey','87682'),(529,'Surrey','87682'),(530,'Surrey','87682'),(531,'Surrey','87682'),(532,'Surrey','87682'),(533,'Cáceres','41401'),(534,'Signeulx','71949'),(535,'Herne','21810'),(536,'Madison','K1R 9B3'),(537,'Virginal-Samme','30532'),(538,'Sooke','24347'),(539,'Aserrí','1159'),(540,'Marilles','50484'),(541,'Whitewater Region Township','62245'),(542,'Surrey','87682'),(543,'Cáceres','41401'),(544,'Signeulx','71949'),(545,'Herne','21810'),(546,'Madison','K1R 9B3'),(547,'Virginal-Samme','30532'),(548,'Sooke','24347'),(549,'Aserrí','1159'),(550,'Marilles','50484'),(551,'Whitewater Region Township','62245'),(552,'Abaetetuba','4271'),(553,'Orbais','31914'),(554,'Jemeppe-sur-Sambre','YQ2 1VO'),(555,'Robelmont','6075'),(556,'Cheltenham','5161PD'),(557,'Idaho Falls','95565-163'),(558,'Montoggio','X5G 3X3'),(559,'Cowdenbeath','Xxxx'),(560,'Gibbons','Xxxx'),(561,'Gavorrano','41504'),(562,'Cercemaggiore','37650'),(563,'Cholet','11641'),(564,'Owen Sound','24874'),(565,'Curitiba','I5F 8NV'),(566,'Todi','98873-257'),(567,'Houtain-le-Val','O8 9GQ'),(568,'Maranello','54012'),(569,'Vancouver','276'),(570,'Ellon','92594-034'),(571,'Kasterlee','51561'),(572,'Mottola','X7Z 1H9'),(573,'Lineburg','5893'),(574,'Reno','0396DA'),(575,'Weiterstadt','7192'),(576,'Northumberland','92821'),(577,'Greater Hobart','62415'),(578,'Pescopagano','9423'),(579,'Amelia','65470'),(580,'Anthisnes','5667ZH'),(581,'Pessac','46119'),(582,'Stonewall','2070'),(583,'Gulfport','67688'),(584,'Portobuffolè','71202'),(585,'Clearwater Municipal District','E7M 5W1'),(586,'Meise','61391'),(587,'Prè-Saint-Didier','K24 5ZA'),(588,'Pulderbos','29722'),(589,'Strasbourg','IG9N 7NC'),(590,'Haguenau','73299-643'),(591,'Clermont-Ferrand','51209'),(592,'Carleton','28092-441'),(593,'Cavasso Nuovo','05561-323'),(594,'Bodmin','DU8 7OE'),(595,'Eckville','3363'),(596,'Wiesbaden','54874'),(597,'La Baie','3966XJ'),(598,'Strathcona County','03638-016'),(599,'Caplan','40701'),(600,'Carson City','10922'),(601,'Taunusstein','7616MX'),(602,'Vierzon','9374'),(603,'Tampa','33000'),(604,'Roosbeek','HF25 8PW'),(605,'Villa Cortese','92505'),(606,'Trieste','47775-097'),(607,'Toulouse','10016'),(608,'Kimberly','7175RS'),(609,'Grasse','KG21 7KC'),(610,'Wrigley','83930'),(611,'Zolder','10127'),(612,'Vielsalm','14298'),(613,'Palmerston','37649'),(614,'Sgonico','A0K 1V4'),(615,'Sint-Martens-Bodegem','76629'),(616,'Santa Fiora','54776'),(617,'Okotoks','71212'),(618,'San Piero Patti','89925'),(619,'Klabbeek','87154'),(620,'Torre Cajetani','51300'),(621,'Portland','6830'),(622,'Lamont','VA4 9SH'),(623,'Emines','70478'),(624,'Oetingen','93266'),(625,'Douai','8731CJ'),(626,'Maracalagonis','14270'),(627,'Francofonte','45764-951'),(628,'Chimay','X8J 6B4'),(629,'Pescantina','06313-358'),(630,'Erie','7533'),(631,'Trinità d\'Agultu e Vignola','8509QS'),(632,'Fosses-la-Ville','6397'),(633,'Straubing','44906'),(634,'Owen Sound','3452'),(635,'Asse','Xxxx'),(636,'Guadalupe','Xxxx'),(637,'Recogne','2788'),(638,'Sommethonne','78128'),(639,'Osgoode','4228'),(640,'Amqui','10217'),(641,'Oxford County','9749'),(642,'Surrey','87682'),(643,'Cáceres','41401'),(644,'Signeulx','71949'),(645,'Herne','21810'),(646,'Madison','K1R 9B3'),(647,'Virginal-Samme','30532'),(648,'Sooke','24347'),(649,'Aserrí','1159'),(650,'Marilles','50484'),(651,'Whitewater Region Township','62245'),(652,'Abaetetuba','4271'),(653,'Orbais','31914'),(654,'Jemeppe-sur-Sambre','YQ2 1VO'),(655,'Robelmont','6075'),(656,'Cheltenham','5161PD'),(657,'Idaho Falls','95565-163'),(658,'Montoggio','X5G 3X3'),(659,'Cowdenbeath','Xxxx'),(660,'Gibbons','Xxxx'),(661,'Gavorrano','41504'),(662,'Cercemaggiore','37650'),(663,'Cholet','11641'),(664,'Owen Sound','24874'),(665,'Curitiba','I5F 8NV'),(666,'Todi','98873-257'),(667,'Houtain-le-Val','O8 9GQ'),(668,'Maranello','54012'),(669,'Vancouver','276'),(670,'Ellon','92594-034'),(671,'Kasterlee','51561'),(672,'Mottola','X7Z 1H9'),(673,'Lineburg','5893'),(674,'Reno','0396DA'),(675,'Weiterstadt','7192'),(676,'Northumberland','92821'),(677,'Greater Hobart','62415'),(678,'Pescopagano','9423'),(679,'Amelia','65470'),(680,'Anthisnes','5667ZH'),(681,'Pessac','46119'),(682,'Stonewall','2070'),(683,'Gulfport','67688'),(684,'Portobuffolè','71202'),(685,'Clearwater Municipal District','E7M 5W1'),(686,'Meise','61391'),(687,'Prè-Saint-Didier','K24 5ZA'),(688,'Pulderbos','29722'),(689,'Strasbourg','IG9N 7NC'),(690,'Haguenau','73299-643'),(691,'Clermont-Ferrand','51209'),(692,'Carleton','28092-441'),(693,'Cavasso Nuovo','05561-323'),(694,'Bodmin','DU8 7OE'),(695,'Eckville','3363'),(696,'Wiesbaden','54874'),(697,'La Baie','3966XJ'),(698,'Strathcona County','03638-016'),(699,'Caplan','40701'),(700,'Carson City','10922'),(701,'Taunusstein','7616MX'),(702,'Vierzon','9374'),(703,'Tampa','33000'),(704,'Roosbeek','HF25 8PW'),(705,'Villa Cortese','92505'),(706,'Trieste','47775-097'),(707,'Toulouse','10016'),(708,'Kimberly','7175RS'),(709,'Grasse','KG21 7KC'),(710,'Wrigley','83930'),(711,'Zolder','10127'),(712,'Vielsalm','14298'),(713,'Palmerston','37649'),(714,'Sgonico','A0K 1V4'),(715,'Sint-Martens-Bodegem','76629'),(716,'Santa Fiora','54776'),(717,'Okotoks','71212'),(718,'San Piero Patti','89925'),(719,'Klabbeek','87154'),(720,'Torre Cajetani','51300'),(721,'Portland','6830'),(722,'Lamont','VA4 9SH'),(723,'Emines','70478'),(724,'Oetingen','93266'),(725,'Douai','8731CJ'),(726,'Maracalagonis','14270'),(727,'Francofonte','45764-951'),(728,'Chimay','X8J 6B4'),(729,'Pescantina','06313-358'),(730,'Erie','7533'),(731,'Trinità d\'Agultu e Vignola','8509QS'),(732,'Fosses-la-Ville','6397'),(733,'Straubing','44906'),(734,'Owen Sound','3452'),(735,'Asse','Xxxx'),(736,'Guadalupe','Xxxx'),(737,'Recogne','2788'),(738,'Sommethonne','78128'),(739,'Osgoode','4228'),(740,'Amqui','10217'),(741,'Oxford County','9749'),(742,'Surrey','87682'),(743,'Cáceres','41401'),(744,'Signeulx','71949'),(745,'Herne','21810'),(746,'Madison','K1R 9B3'),(747,'Virginal-Samme','30532'),(748,'Sooke','24347'),(749,'Aserrí','1159'),(750,'Marilles','50484'),(751,'Whitewater Region Township','62245'),(752,'Abaetetuba','4271'),(753,'Orbais','31914'),(754,'Jemeppe-sur-Sambre','YQ2 1VO'),(755,'Robelmont','6075'),(756,'Cheltenham','5161PD'),(757,'Idaho Falls','95565-163'),(758,'Montoggio','X5G 3X3'),(759,'Cowdenbeath','Xxxx'),(760,'Gibbons','Xxxx'),(761,'Gavorrano','41504'),(762,'Cercemaggiore','37650'),(763,'Cholet','11641'),(764,'Owen Sound','24874'),(765,'Curitiba','I5F 8NV'),(766,'Todi','98873-257'),(767,'Houtain-le-Val','O8 9GQ'),(768,'Maranello','54012'),(769,'Vancouver','276'),(770,'Ellon','92594-034'),(771,'Kasterlee','51561'),(772,'Mottola','X7Z 1H9'),(773,'Lineburg','5893'),(774,'Reno','0396DA'),(775,'Weiterstadt','7192'),(776,'Northumberland','92821'),(777,'Greater Hobart','62415'),(778,'Pescopagano','9423'),(779,'Amelia','65470'),(780,'Anthisnes','5667ZH'),(781,'Pessac','46119'),(782,'Stonewall','2070'),(783,'Gulfport','67688'),(784,'Portobuffolè','71202'),(785,'Clearwater Municipal District','E7M 5W1'),(786,'Meise','61391'),(787,'Prè-Saint-Didier','K24 5ZA'),(788,'Pulderbos','29722'),(789,'Strasbourg','IG9N 7NC'),(790,'Haguenau','73299-643'),(791,'Clermont-Ferrand','51209'),(792,'Carleton','28092-441'),(793,'Cavasso Nuovo','05561-323'),(794,'Bodmin','DU8 7OE'),(795,'Eckville','3363'),(796,'Wiesbaden','54874'),(797,'La Baie','3966XJ'),(798,'Strathcona County','03638-016'),(799,'Caplan','40701'),(800,'Carson City','10922'),(801,'Taunusstein','7616MX'),(802,'Vierzon','9374'),(803,'Tampa','33000'),(804,'Roosbeek','HF25 8PW'),(805,'Villa Cortese','92505'),(806,'Trieste','47775-097'),(807,'Toulouse','10016'),(808,'Kimberly','7175RS'),(809,'Grasse','KG21 7KC'),(810,'Wrigley','83930'),(811,'Zolder','10127'),(812,'Vielsalm','14298'),(813,'Palmerston','37649'),(814,'Sgonico','A0K 1V4'),(815,'Sint-Martens-Bodegem','76629'),(816,'Santa Fiora','54776'),(817,'Okotoks','71212'),(818,'San Piero Patti','89925'),(819,'Klabbeek','87154'),(820,'Torre Cajetani','51300'),(821,'Portland','6830'),(822,'Lamont','VA4 9SH'),(823,'Emines','70478'),(824,'Oetingen','93266'),(825,'Douai','8731CJ'),(826,'Maracalagonis','14270'),(827,'Francofonte','45764-951'),(828,'Chimay','X8J 6B4'),(829,'Pescantina','06313-358'),(830,'Erie','7533'),(831,'Trinità d\'Agultu e Vignola','8509QS'),(832,'Fosses-la-Ville','6397'),(833,'Straubing','44906'),(834,'Owen Sound','3452'),(835,'Asse','Xxxx'),(836,'Guadalupe','Xxxx'),(837,'Recogne','2788'),(838,'Sommethonne','78128'),(839,'Osgoode','4228'),(840,'Amqui','10217'),(841,'Oxford County','9749'),(842,'Surrey','87682'),(843,'Cáceres','41401'),(844,'Signeulx','71949'),(845,'Herne','21810'),(846,'Madison','K1R 9B3'),(847,'Virginal-Samme','30532'),(848,'Sooke','24347'),(849,'Aserrí','1159'),(850,'Marilles','50484'),(851,'Whitewater Region Township','62245'),(852,'Abaetetuba','4271'),(853,'Orbais','31914'),(854,'Jemeppe-sur-Sambre','YQ2 1VO'),(855,'Robelmont','6075'),(856,'Cheltenham','5161PD'),(857,'Idaho Falls','95565-163'),(858,'Montoggio','X5G 3X3'),(859,'Cowdenbeath','Xxxx'),(860,'Gibbons','Xxxx'),(861,'Gavorrano','41504'),(862,'Cercemaggiore','37650'),(863,'Cholet','11641'),(864,'Owen Sound','24874'),(865,'Curitiba','I5F 8NV'),(866,'Todi','98873-257'),(867,'Houtain-le-Val','O8 9GQ'),(868,'Maranello','54012'),(869,'Vancouver','276'),(870,'Ellon','92594-034'),(871,'Kasterlee','51561'),(872,'Mottola','X7Z 1H9'),(873,'Lineburg','5893'),(874,'Reno','0396DA'),(875,'Weiterstadt','7192'),(876,'Northumberland','92821'),(877,'Greater Hobart','62415'),(878,'Pescopagano','9423'),(879,'Amelia','65470'),(880,'Anthisnes','5667ZH'),(881,'Pessac','46119'),(882,'Stonewall','2070'),(883,'Gulfport','67688'),(884,'Portobuffolè','71202'),(885,'Clearwater Municipal District','E7M 5W1'),(886,'Meise','61391'),(887,'Prè-Saint-Didier','K24 5ZA'),(888,'Pulderbos','29722'),(889,'Strasbourg','IG9N 7NC'),(890,'Haguenau','73299-643'),(891,'Clermont-Ferrand','51209'),(892,'Carleton','28092-441'),(893,'Cavasso Nuovo','05561-323'),(894,'Bodmin','DU8 7OE'),(895,'Eckville','3363'),(896,'Wiesbaden','54874'),(897,'La Baie','3966XJ'),(898,'Strathcona County','03638-016'),(899,'Caplan','40701'),(900,'Carson City','10922'),(901,'Taunusstein','7616MX'),(902,'Vierzon','9374'),(903,'Tampa','33000'),(904,'Roosbeek','HF25 8PW'),(905,'Villa Cortese','92505'),(906,'Trieste','47775-097'),(907,'Toulouse','10016'),(908,'Kimberly','7175RS'),(909,'Grasse','KG21 7KC'),(910,'Wrigley','83930'),(911,'Zolder','10127'),(912,'Vielsalm','14298'),(913,'Palmerston','37649'),(914,'Sgonico','A0K 1V4'),(915,'Sint-Martens-Bodegem','76629'),(916,'Santa Fiora','54776'),(917,'Okotoks','71212'),(918,'San Piero Patti','89925'),(919,'Klabbeek','87154'),(920,'Torre Cajetani','51300'),(921,'Portland','6830'),(922,'Lamont','VA4 9SH'),(923,'Emines','70478'),(924,'Oetingen','93266'),(925,'Douai','8731CJ'),(926,'Maracalagonis','14270'),(927,'Francofonte','45764-951'),(928,'Chimay','X8J 6B4'),(929,'Pescantina','06313-358'),(930,'Erie','7533'),(931,'Trinità d\'Agultu e Vignola','8509QS'),(932,'Fosses-la-Ville','6397'),(933,'Straubing','44906'),(934,'Owen Sound','3452'),(935,'Asse','Xxxx'),(936,'Guadalupe','Xxxx'),(937,'Recogne','2788'),(938,'Sommethonne','78128'),(939,'Osgoode','4228'),(940,'Amqui','10217'),(941,'Oxford County','9749'),(942,'Surrey','87682'),(943,'Cáceres','41401'),(944,'Signeulx','71949'),(945,'Herne','21810'),(946,'Madison','K1R 9B3'),(947,'Virginal-Samme','30532'),(948,'Sooke','24347'),(949,'Aserrí','1159'),(950,'Marilles','50484'),(951,'Whitewater Region Township','62245'),(952,'Abaetetuba','4271'),(953,'Orbais','31914'),(954,'Jemeppe-sur-Sambre','YQ2 1VO'),(955,'Robelmont','6075'),(956,'Cheltenham','5161PD'),(957,'Idaho Falls','95565-163'),(958,'Montoggio','X5G 3X3'),(959,'Cowdenbeath','Xxxx'),(960,'Gibbons','Xxxx'),(961,'Gavorrano','41504'),(962,'Cercemaggiore','37650'),(963,'Cholet','11641'),(964,'Owen Sound','24874'),(965,'Curitiba','I5F 8NV'),(966,'Todi','98873-257'),(967,'Houtain-le-Val','O8 9GQ'),(968,'Maranello','54012'),(969,'Vancouver','276'),(970,'Ellon','92594-034'),(971,'Kasterlee','51561'),(972,'Mottola','X7Z 1H9'),(973,'Lineburg','5893'),(974,'Reno','0396DA'),(975,'Weiterstadt','7192'),(976,'Northumberland','92821'),(977,'Greater Hobart','62415'),(978,'Pescopagano','9423'),(979,'Amelia','65470'),(980,'Anthisnes','5667ZH'),(981,'Pessac','46119'),(982,'Stonewall','2070'),(983,'Gulfport','67688'),(984,'Portobuffolè','71202'),(985,'Clearwater Municipal District','E7M 5W1'),(986,'Meise','61391'),(987,'Prè-Saint-Didier','K24 5ZA'),(988,'Pulderbos','29722'),(989,'Strasbourg','IG9N 7NC'),(990,'Haguenau','73299-643'),(991,'Clermont-Ferrand','51209'),(992,'Carleton','28092-441'),(993,'Cavasso Nuovo','05561-323'),(994,'Bodmin','DU8 7OE'),(995,'Eckville','3363'),(996,'Wiesbaden','54874'),(997,'La Baie','3966XJ'),(998,'Strathcona County','03638-016'),(999,'Caplan','40701'),(1000,'Carson City','10922'),(1001,'Taunusstein','7616MX'),(1002,'Vierzon','9374'),(1003,'Tampa','33000'),(1004,'Roosbeek','HF25 8PW'),(1005,'Villa Cortese','92505'),(1006,'Trieste','47775-097'),(1007,'Toulouse','10016'),(1008,'Kimberly','7175RS'),(1009,'Grasse','KG21 7KC'),(1010,'Wrigley','83930'),(1011,'Zolder','10127'),(1012,'Vielsalm','14298'),(1013,'Palmerston','37649'),(1014,'Sgonico','A0K 1V4'),(1015,'Sint-Martens-Bodegem','76629'),(1016,'Santa Fiora','54776'),(1017,'Okotoks','71212'),(1018,'San Piero Patti','89925'),(1019,'Klabbeek','87154'),(1020,'Torre Cajetani','51300'),(1021,'Portland','6830'),(1022,'Lamont','VA4 9SH'),(1023,'Emines','70478'),(1024,'Oetingen','93266'),(1025,'Douai','8731CJ'),(1026,'Maracalagonis','14270'),(1027,'Francofonte','45764-951'),(1028,'Chimay','X8J 6B4'),(1029,'Pescantina','06313-358'),(1030,'Erie','7533'),(1031,'Trinità d\'Agultu e Vignola','8509QS'),(1032,'Fosses-la-Ville','6397'),(1033,'Straubing','44906'),(1034,'Owen Sound','3452'),(1035,'Asse','Xxxx'),(1036,'Guadalupe','Xxxx'),(1037,'Recogne','2788'),(1038,'Sommethonne','78128'),(1039,'Osgoode','4228'),(1040,'Amqui','10217'),(1041,'Oxford County','9749');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
